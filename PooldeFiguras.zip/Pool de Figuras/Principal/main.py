'''
Created on 13/05/2019

@author: Alvaro
'''

from Pool.Pooldefiguras import Poolfiguras

if __name__ == '__main__':
    pool1 = Poolfiguras()
    pool2 = Poolfiguras()
    
    pool1.getTriangulo()
    pool1.getCirculo()
    pool1.getCuadrado()
    
    pool2.getTriangulo()
    pool2.getCirculo()
    pool2.getCuadrado()
    
    pool2.liberarCirculo()
    
    pool1.getCirculo()
    

    
