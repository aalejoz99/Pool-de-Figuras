'''
Created on 13/05/2019

@author: Alvaro
'''

from Pool.Pooldefiguras import Poolfiguras
from Vista.Vista import Vista
from tkinter import Button

if __name__ == '__main__':
    
    
    pool2 = Poolfiguras()
    
  
    
    pool2.getTriangulo()
    pool2.getCirculo()
    pool2.getCuadrado()
    
    pool2.liberarCirculo()
    
    
    
    
    Vista1 = Vista()


    

    
